// const express = require("express");
// const MedicineStatus = require("../models/MedicineStatus");
// const { verifyToken } = require("../middleware/auth"); // assuming you use JWT

// const router = express.Router();

// // Save medicine status
// router.post("/", verifyToken, async (req, res) => {
//   try {
//     const { userId, medicineId, medicineName, doseTime, status } = req.body;

//     if (!userId || !medicineId || !doseTime || !status) {
//       return res.status(400).json({ success: false, message: "Missing fields" });
//     }

//     const log = new MedicineStatus({
//       userId,
//       medicineId,
//       medicineName,
//       doseTime,
//       status,
//     });

//     await log.save();

//     res.json({ success: true, message: "Medicine status saved", data: log });
//   } catch (err) {
//     console.error("Error saving medicine status:", err);
//     res.status(500).json({ success: false, error: err.message });
//   }
// });

// // Fetch all logs for a user
// router.get("/:userId", verifyToken, async (req, res) => {
//   try {
//     const logs = await MedicineStatus.find({ userId: req.params.userId }).sort({ timestamp: -1 });
//     res.json({ success: true, data: logs });
//   } catch (err) {
//     res.status(500).json({ success: false, error: err.message });
//   }
// });

// module.exports = router;


const express = require("express");
const MedicineStatus = require("../models/MedicineStatus");

const router = express.Router();

// ✅ Save medicine status (Taken / Not Taken)
const mongoose = require('mongoose');

router.post("/", async (req, res) => {
  try {
    const { userId, medicineId, medicineName, doseTime, status } = req.body;

    if (!userId || !medicineName || !doseTime || !status) {
      return res.status(400).json({ success: false, message: "Missing fields" });
    }

    const log = new MedicineStatus({
    //    userId: new mongoose.Types.ObjectId(userId),  
    //   medicineId: medicineId ? mongoose.Types.ObjectId(medicineId) : undefined,
    userId: new mongoose.Types.ObjectId(req.body.userId),
    medicineId: new mongoose.Types.ObjectId(req.body.medicineId),
      medicineName,
      doseTime,
      status
    });

    await log.save();
    res.json({ success: true, message: "Medicine status saved", data: log });
  } catch (err) {
    console.error("Error saving medicine status:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});


// ✅ Fetch all logs for a user
router.get("/:userId", async (req, res) => {
  try {
    const logs = await MedicineStatus.find({ userId: req.params.userId }).sort({
      timestamp: -1,
    });
    res.json({ success: true, data: logs });
  } catch (err) {
    console.error("Error fetching logs:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
