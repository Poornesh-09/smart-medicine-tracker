const mongoose = require("mongoose");

const medicineStatusSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  medicineId: { type: mongoose.Schema.Types.ObjectId, ref: "Medicine"}, // link to Medicine
  medicineName: { type: String, required: true }, // keep name in case medicine is deleted
  doseTime: { type: String, required: true }, // e.g. "09:00"
  status: { type: String, enum: ["taken", "not_taken"], required: true },
  timestamp: { type: Date, default: Date.now }, // when the user responded
  notified: { type: Boolean, default: false }
});

module.exports = mongoose.model("MedicineStatus", medicineStatusSchema);
