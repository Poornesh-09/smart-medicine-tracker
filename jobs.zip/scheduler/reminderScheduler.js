// // reminderScheduler.js
// const Medicine = require("../models/Medicine");
// const TrustedMember = require("../models/TrustedMember");
// const { sendNotificationToTrusted } = require("../utils/notifications");

// async function checkMissedMedicines() {
//   const now = new Date();

//   // 2 minutes ago
//   const twoMinutesAgo = new Date(now.getTime() - 2 * 60 * 1000);
//   // 5 minutes ago (safety window)
//   const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);

//   // Find medicines whose doseTime is in the last 5 mins but not taken
//   const missed = await Medicine.find({
//     taken: false,
//     doseTime: { $gte: fiveMinutesAgo, $lte: twoMinutesAgo }
//   });

//   for (const med of missed) {
//     const trustedMembers = await TrustedMember.find({ user: med.user });
//     if (!trustedMembers.length) {
//       console.log("No trusted members found!");
//       continue;
//     }

//     const emails = trustedMembers.map(m => m.email);
//     const message = `${med.medicineName} was not taken at ${med.doseTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
//     console.log(`Sending notification for ${med.medicineName} to trusted members:`, emails);

//     await sendNotificationToTrusted(emails, message);
//   }
// }

// module.exports = { checkMissedMedicines };

// // reminderScheduler.js
// const Medicine = require("../models/Medicine");
// const TrustedMember = require("../models/TrustedMember");
// const { sendNotificationToTrusted } = require("../utils/notifications");

// async function checkMissedMedicines() {
//   const now = new Date();

//   const twoMinutesAgo = new Date(now.getTime() - 2 * 60 * 1000);
//   const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);

//   // Find medicines whose doseTime is in the last 5 mins but not taken
//   const missed = await Medicine.find({
//     taken: false,
//     doseTime: { $gte: fiveMinutesAgo, $lte: twoMinutesAgo }
//   });

//   for (const med of missed) {
//     const trustedMembers = await TrustedMember.find({ user: med.user });
//     if (!trustedMembers.length) {
//       console.log("No trusted members found!");
//       continue;
//     }

//     for (const member of trustedMembers) {
//       const message = `
// Hello ${member.name || "Trusted Member"},

// We wanted to let you know that ${
//         med.userName || "your family member"
//       } missed their scheduled dose of **${med.medicineName}** at **${med.doseTime.toLocaleTimeString([], {
//         hour: "2-digit",
//         minute: "2-digit",
//       })}**.

// Please check in with them and make sure everything is okay.  
// Your support really helps them stay healthy. 💖  

// – Smart Medicine Tracker
// `;

//       console.log(
//         `Sending notification for ${med.medicineName} to: ${member.email}`
//       );

//       await sendNotificationToTrusted([member.email], message);
//     }
//   }
// }

// module.exports = { checkMissedMedicines };
// scheduler/reminderScheduler.js
const mongoose = require("mongoose"); // ensure mongoose is imported
const Medicine = require("../models/Medicine");
const TrustedMember = require("../models/TrustedMember");
const User = require("../models/User");
const { sendNotificationToTrusted } = require("../utils/notifications");

async function checkMissedMedicines() {
  const now = new Date();
  console.log("⏰ Running checkMissedMedicines at", now.toLocaleTimeString());

  // 2 minutes ago
  const twoMinutesAgo = new Date(now.getTime() - 2 * 60 * 1000);
  // 5 minutes ago (safety window)
  const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);

  // Find medicines whose doseTime is in the last 5 mins but not taken
  const missed = await Medicine.find({
    taken: false,
    doseTime: { $gte: fiveMinutesAgo, $lte: twoMinutesAgo }
  });

  console.log(`Found ${missed.length} missed medicines`);

  for (const med of missed) {
    console.log("Processing medicine:", med.medicineName, "for userId:", med.user);

    // Find trusted members
    const trustedMembers = await TrustedMember.find({ user: med.user });
    console.log(`Found ${trustedMembers.length} trusted members`);

    if (!trustedMembers.length) continue;

    // Fetch patient/user name safely using ObjectId
    const patient = await User.findById(mongoose.Types.ObjectId(med.user)).select("name");
    const patientName = patient ? patient.name : "your family member";

    const formattedTime = med.doseTime.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit"
    });

    // Send alert to each trusted member
    for (const tm of trustedMembers) {
      console.log(`Sending alert to ${tm.name} (${tm.email}) for medicine ${med.medicineName} at ${formattedTime}, patientName=${patientName}`);
      await sendNotificationToTrusted(
        tm.email,          // trusted member email
        tm.name,           // trusted member name
        med.medicineName,  // medicine name
        formattedTime,     // dose time
        patientName,       // patient name
         med.shape,       // medicine shape
         med.color
      );
    }
  }

  console.log("✅ checkMissedMedicines run completed");
}

module.exports = { checkMissedMedicines };


